package com.hellodemo.hellodemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
